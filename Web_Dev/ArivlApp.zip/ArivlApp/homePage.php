<!DOCTYPE html>
<html>
<head>
	<title>HomePage</title>
	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width, initial-scale=1.0">
	<meta name="author" content="StacksonStacks" >
	<link rel = "stylesheet" type = "text/css" href = "homepage.css"></link>
	<script src = "jquery-3.2.1.js"></script>
	<script src = "./bootstrap-3.3.4-dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="./bootstrap-3.3.4-dist/css/bootstrap.min.css"></link>
</head>
<body class = "tyler">
	<div class= "container-fluid">
		<form action="loginPortal.php" method="POST" >
			<div class = "container">
				<img src="arivl.png" alt="arivl logo"/>

			</div>
			
			<div class="container" style="text-align: left;">
				<label for="uname">
					<b>Username
				</label>
				<input type="text" name="uname" id="uname" placeholder="Enter username" required><br>
				<label for="psw">
					<b>Password</b>
				</label>
				<input type="password" name="psw" id="psw" placeholder="Enter Password" required><br>
				<button type="submit" class ="btn btn-success">
					Login
				</button>
				<label for="rem">
					Remember Me
				</label>
				<input type="checkbox" checked="checked" id="" name="remember">
				
			</div>
			<div class="container" style="text-align: left;">
				<button class ="btn btn-danger" type="button" class="cancelbtn">
					Cancel
				</button>
				<span class="psw">
					Forget <a href="#">Password?</a>
				</span>
			</div>
		</form>
	</div>
</body>
</html>