<?php 
	session_start();
	include "database.php";
	//echo $_SESSION['name'];
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Welcome <?php echo $_SESSION['name']; ?></title>
 	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width, initial-scale=1.0">
	<link rel = "stylesheet" type = "text/css" href = "homepage.css"></link>
	<script src = "jquery-3.2.1.js"></script>
	<script src = "./bootstrap-3.3.4-dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="./bootstrap-3.3.4-dist/css/bootstrap.min.css"></link>
 </head>
 <body style="background-color: #cacecf;">
 	<div class="container-fluid">
 		</data><h1>WELCOME TO ARIVLAPP RESIDENTIAL PORTAL</h1>
 		<h2>BELOW <?php echo $_SESSION['name']; ?> MAY ADD A GUEST USER</h2>
 	</div>
	<div class="container">
	 	<form method="POST" action="addGuest.php">
	 		<label for="name">
	 			Name:
	 		</label>
	 		<input type="text" name="name" placeholder="Guest Name" required ><br>
	 		<label for="surname">
	 			Surname:
	 		</label>
	 		<input type="text" name="surname" placeholder="Guest Surname" required><br>

	 		<label for="id">ID Number:</label>
	 		<input type="text" name="id" placeholder="Guest ID number" required><br>

	 		<label for="number">Mobile Number</label>
	 		<input type="text" name="number" placeholder="Guest Mobile Number" required><br>

	 		<label for="License">License Plate</label>
	 		<input type="text" name="license" placeholder="License Plate" required><br>

	  		<label for="email">Email Address</label>
	 		<input type="text" name="email" placeholder="email" required><br> 	
	</div>
	<div class="container">
		<button type="submit" class="btn btn-success">Submit</button>
		<button type="button" class="btn btn-danger">Cancel</button>		
	</div>
	</form>
 </body>
 </html>