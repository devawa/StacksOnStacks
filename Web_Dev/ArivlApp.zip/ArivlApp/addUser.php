<?php
	session_start();
	include 'database.php';
	$name= $_POST['name'];
	$surname= $_POST['surname'];
	$id= $_POST['id'];
	$number= $_POST['number'];
	$license = $_POST['license'];
	$email =  $_POST['email'];
	$password = "temp";
	$query = "insert into users 
				(name,surname,number,idNumber,license,email,active,guestRequest,resident,loggedOn,password)
				VALUES ('$name','$surname','$number','$id','$license','$email',0,0,1,0,'$password')"; 
	if($result = $conn->query($query))
	{
		//echo "inside 1"; 
		$sql = "SELECT * FROM users WHERE idNumber = '$id'" ;
		$result = $conn->query($sql);
		
		if(!$row = $result->fetch_assoc())
		{
				
				echo ("wrong username or passsword");
			//	header("Location: homePage.php");
		}else{
			$user_id = $row['user_id'];
			$userId = $_SESSION['id'];
			echo "!!!!".$userId;
			echo "????". $user_id."????";
			$query = "SELECT * from privileges WHERE user_id = '$userId'";
			$result = $conn->query($query);
			
			if($row = $result->fetch_assoc())
			{				
				$estate = $row['estate'];
				$query = "insert into privileges (user_id,criteria,estate,activeEstate) values ($user_id, 'Resident','$estate',1)";
				if($result = $conn->query($query))
				{
					header("Location:admin.php");
				}
				else
				{
					echo"Estate does not exist";
				}
			}
			else
			{
				die("Error");
			}
		}
		
	}
	else{
		die ("something went wrong");
	}
?>