$(document).ready(function(){
    $("button").click(function(){
        alert("hi" + $("button").val());
    });
});