<?php
		session_start();
		//phpinfo();
		include 'database.php';
		$use = $_POST['uname'];
		$pass = $_POST['psw'];
		$_SESSION['password'] = $pass;
		$_SESSION['username'] = $use;
		$sql = "SELECT * FROM users WHERE name='$use' AND password ='$pass' ";
		$result = $conn->query($sql);
		
		if($row = $result->fetch_assoc())
		{
			$id = $row['user_id'];
			$sql1 = "SELECT * FROM privileges WHERE user_id ='$id' AND criteria ='Admin'";
			$result = $conn->query($sql1);
			if($result = $conn->query($sql))
			{
				echo "you are logged in to your username!";
				$_SESSION['name'] = $row['name'];
				$_SESSION['id'] = $row['user_id'];
				echo $_SESSION['id'];
				header("Location: admin.php");
			}
			else
			{
				echo "you are logged in to your username!";
				$_SESSION['name'] = $row['name'];
				$_SESSION['id'] = $row['user_id'];
				echo $_SESSION['name'];
				 header("Location: resident.php");
			}
		}
		
		//Admin
		/*$sql1 = "SELECT * FROM admin WHERE name='$use' AND password ='$pass' ";
		if($conn->query($sql1) === FALSE) 
		{
			die('Could not enter data: ' );
		}
		$result = $conn->query($sql1)
		if($result->num_rows > 0)
		{
				header("Location: resident.php");
		}*/
		else 
		{
			echo ("wrong username or passsword");
				//header("Location: homePage.php");
		}
		//if(isset($_SESSION['id'])){echo 'wedo';}
		//$result = $conn->query($sql);
		
	?>
